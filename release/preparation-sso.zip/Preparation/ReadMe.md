# install  LDAP and SSO




Connect to database:



		psql postgresql://<server>:5432/ssodb  --username=nikoadmin


useful commands:

		\l list databases
		\dt list tables in current database



## Vagrant

edit file:

 		 /var/lib/pgsql/data/postgresql.conf


change line to:


		listen_addresses = '*'


login:



		psql postgresql://10.42.0.3:5432/keycloak  -U niko  -W



## Ldap


check if status on web:

                    http://10.42.0.2:9830/

user admin
pass test


ldap entry:

                    dn: uid=nmajorov, ou=People, dc=goteborg,dc=se
                    objectClass: inetOrgPerson
                    cn: Nikolaj Majorov
                    sn: Majorov
                    uid: nmajorov


to add call following command:


                    ldapadd -x -v  -f /tmp/ldap_entry  -D "cn=directory manager" -w test
