#!/bin/bash

ansible-playbook \
    -e dirsrv_fqdn=ldap.goteborg.se \
    -e dirsrv_password=test \
     install_ldap.yml
