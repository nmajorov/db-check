#!/bin/bash

#sudo -s bash -c  "firewallctl zone FedoraWorkstation  add  port 80/tcp"
ansible-playbook  \
    -e targethosts=ssodemo  \
    -e postgresql_server=localhost \
    -e download_uri=$HOME/Downloads \
    install_sso.yml
