#!/bin/sh
# 
# author Nikolaj Majorov nmajorov@redhat.com
# start fuse from clean state
# it remove tmp directory and all not related to fuse deployments 
# copy it in the $FUSE_EAP_HOME/bin and start it


DIRNAME=`dirname "$0"`
PROGNAME=`basename "$0"`

dir_to_remove=( "data" "log" "tmp")
for dir in ${dir_to_remove[@]}
do
  rm -fr  $DIRNAME/../standalone/$dir
done


deployments=$(find $DIRNAME/../standalone/deployments -type f -name "*" -not -name "hawtio-*" -not -name "redhat-bran*")

for i in $deployments
do
    echo "remove deployments: $i"
    rm -rf  $i
done



$DIRNAME/standalone.sh
